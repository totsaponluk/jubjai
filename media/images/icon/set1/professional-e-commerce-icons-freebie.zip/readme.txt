------------------
Professional E-Commerce Icons
Designed by Web Icons Set (http://www.webiconset.com) and released for Smashing Magazine and its readers.
------------------

Dear friends,

thank you for downloading this file.

This freebie has been brought to you by SmashingMagazine.com.
You can freely use it for both your private and commercial projects, including software, online services, templates and themes.
The set may not be resold, sublicensed or rented. The set may not be offered for free downloading from websites other than SmashingMagazine.com.
Please link to the article in which this freebie was released if you want to spread the word.

Smashing Magazine Team,
www.smashingmagazine.com
